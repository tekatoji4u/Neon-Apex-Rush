import {
  ArcRotateCamera, Color3, Color4, DirectionalLight, Engine, GlowLayer, HemisphericLight, Mesh, MeshBuilder, Scene, StandardMaterial, Texture, Vector3,
} from '@babylonjs/core';

export type GameHandle = { scene: Scene; dispose: () => void };
type Car = { root: Mesh; lane: number; speed: number; color: Color3; phase: number };

const laneX = [-3.6, 0, 3.6];
const roadZ = 240;
const makeMat = (scene: Scene, name: string, color: Color3, emissive = false) => {
  const mat = new StandardMaterial(name, scene); mat.diffuseColor = color; mat.specularColor = new Color3(.25,.25,.25);
  if (emissive) mat.emissiveColor = color.scale(.8); return mat;
};
const carMesh = (scene: Scene, name: string, body: Color3, glow: GlowLayer) => {
  const root = MeshBuilder.CreateBox(name, {width: 2.5, height: .62, depth: 4.6}, scene); root.material = makeMat(scene, name+'body', body);
  const cabin = MeshBuilder.CreateBox(name+'cabin', {width: 1.75, height: .5, depth: 1.8}, scene); cabin.parent = root; cabin.position.y = .5; cabin.position.z = -.2; cabin.material = makeMat(scene, name+'glass', new Color3(.035,.08,.16), true);
  const hood = MeshBuilder.CreateBox(name+'hood', {width: 2.1, height: .18, depth: 1.2}, scene); hood.parent=root; hood.position.y=.34; hood.position.z=1.45; hood.material=makeMat(scene,name+'hood',body.scale(.75));
  for (const x of [-.88,.88]) { for (const z of [-1.55,1.55]) { const w=MeshBuilder.CreateCylinder(name+'wheel',{diameter:.62,height:.22,tessellation:16},scene); w.parent=root; w.rotation.z=Math.PI/2; w.position.set(x,-.35,z); w.material=makeMat(scene,name+'tire',new Color3(.015,.018,.025)); } }
  const tail = MeshBuilder.CreateBox(name+'tail',{width:1.8,height:.12,depth:.08},scene); tail.parent=root; tail.position.set(0,.2,-2.3); tail.material=makeMat(scene,name+'tail',new Color3(1,.03,.12),true); glow.addIncludedOnlyMesh(tail);
  return root;
};

export async function createGameScene(engine: Engine, canvas: HTMLCanvasElement): Promise<GameHandle> {
  const scene = new Scene(engine); scene.clearColor = new Color4(.025,.018,.08,1);
  const camera = new ArcRotateCamera('chase', -Math.PI/2, 1.04, 15, new Vector3(0,1,14), scene); camera.fov=.82; camera.minZ=.1; camera.attachControl(canvas,false);
  const sun = new DirectionalLight('sun', new Vector3(-.4,-1,.6), scene); sun.intensity=2.1; sun.diffuse=new Color3(1,.55,.32);
  const hemi = new HemisphericLight('hemi', new Vector3(0,1,0), scene); hemi.intensity=.55; hemi.diffuse=new Color3(.25,.45,1); hemi.groundColor=new Color3(.12,.03,.18);
  const glow = new GlowLayer('neonGlow', scene); glow.intensity=1.35;
  const sky = MeshBuilder.CreateSphere('sky',{diameter:500,segments:16},scene); sky.material=makeMat(scene,'sky',new Color3(.16,.025,.22)); sky.material.backFaceCulling=false;
  const ocean = MeshBuilder.CreateGround('ocean',{width:260,height:500},scene); ocean.position.set(95,-1.1,120); ocean.material=makeMat(scene,'ocean',new Color3(.015,.08,.16),true);
  const roadMat=makeMat(scene,'road',new Color3(.055,.06,.09)); const laneMat=makeMat(scene,'lane',new Color3(.78,.86,1),true); const railCyan=makeMat(scene,'cyan',new Color3(0,.8,1),true); const railPink=makeMat(scene,'pink',new Color3(1,.04,.4),true);
  const road=MeshBuilder.CreateGround('road',{width:14,height:roadZ},scene); road.position.z=roadZ/2; road.material=roadMat;
  for(let z=0;z<roadZ;z+=10){ for(const x of [-2.3,2.3]){const mark=MeshBuilder.CreateBox('mark',{width:.12,height:.02,depth:4},scene);mark.position.set(x,.02,z+4);mark.material=laneMat;} for(const x of [-7.15,7.15]){const rail=MeshBuilder.CreateBox('rail',{width:.15,height:.18,depth:10},scene);rail.position.set(x,.28,z+5);rail.material=(z/10%2===0?railCyan:railPink);glow.addIncludedOnlyMesh(rail);} }
  for(let z=8;z<roadZ;z+=22){ for(const side of [-1,1]) {const trunk=MeshBuilder.CreateCylinder('palm',{diameter:.28,height:4.5},scene);trunk.position.set(side*(9+((z/22)%2)*1.5),2,z);trunk.material=makeMat(scene,'trunk',new Color3(.16,.06,.03)); const crown=MeshBuilder.CreateSphere('leaves',{diameter:3.2,segments:8},scene);crown.position.set(trunk.position.x,4.5,z);crown.scaling.set(1.2,.45,1.2);crown.material=makeMat(scene,'leaves',new Color3(.02,.18,.17),true);} }
  const player=carMesh(scene,'player',new Color3(.06,.18,.95),glow); player.position.set(0,.65,10);
  const opponents: Car[] = [
    {root:carMesh(scene,'rivalRed',new Color3(.9,.035,.12),glow),lane:-1,speed:34,color:new Color3(1,.1,.1),phase:0},
    {root:carMesh(scene,'rivalWhite',new Color3(.85,.9,1),glow),lane:1,speed:31,color:new Color3(.8,.9,1),phase:1.7},
  ]; opponents[0].root.position.set(laneX[0],.65,46); opponents[1].root.position.set(laneX[2],.65,70);
  const keys: Record<string,boolean>={}; const down=(e:KeyboardEvent)=>{keys[e.key.toLowerCase()]=true;if([' ','arrowleft','arrowright','arrowup','arrowdown'].includes(e.key.toLowerCase()))e.preventDefault()}; const up=(e:KeyboardEvent)=>{keys[e.key.toLowerCase()]=false}; window.addEventListener('keydown',down);window.addEventListener('keyup',up);
  let elapsed=0; let distance=0; let nitro=76; let disposed=false; let last=performance.now();
  const render = () => { if(disposed)return; const now=performance.now(); const dt=Math.min(.05,(now-last)/1000);last=now; elapsed+=dt; const boosting=!!(keys[' ']||keys['shift']); const steer=(keys['arrowleft']||keys['a']?-1:0)+(keys['arrowright']||keys['d']?1:0); const base=33; const speed=base+(boosting&&nitro>0?20:0); if(boosting&&nitro>0)nitro=Math.max(0,nitro-dt*18); else nitro=Math.min(100,nitro+dt*4);
    player.position.x += steer*dt*7; player.position.x=Math.max(-5.1,Math.min(5.1,player.position.x)); player.rotation.z += (steer*.13-player.rotation.z)*dt*9; distance+=speed*dt;
    for(const o of opponents){o.root.position.z-= (speed-o.speed)*dt; o.root.position.x=laneX[o.lane+1]+Math.sin(elapsed*.7+o.phase)*.2; if(o.root.position.z<6)o.root.position.z=roadZ-18;}
    camera.target.x+=(player.position.x*.32-camera.target.x)*dt*5; camera.target.y+=(1.0-camera.target.y)*dt*5; camera.radius+=(15+(boosting?2:0)-camera.radius)*dt*3; camera.alpha=-Math.PI/2; camera.beta=1.04; camera.fov+=(boosting?.94:.82-camera.fov)*dt*4;
    window.dispatchEvent(new CustomEvent('race-stats',{detail:{speed:Math.round(speed*7.4),nitro:Math.round(nitro),distance,boosting,position:1,lap:Math.min(2,Math.floor(distance/520)+1)}})); scene.render(); requestAnimationFrame(render); };
  requestAnimationFrame(render);
  return {scene,dispose(){disposed=true;window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);scene.dispose();}};
}

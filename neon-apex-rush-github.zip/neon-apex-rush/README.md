# Neon Apex Rush

Neon Apex Rush là game đua xe 3D arcade chạy trong trình duyệt, được xây dựng bằng React, TypeScript, Vite và Babylon.js. Game có đường đua ven biển neon, xe đối thủ, camera bám đuôi, tăng tốc nitro, HUD tốc độ/vòng đua và giao diện toàn màn hình.

## Chạy local

Yêu cầu Node.js 20+ và pnpm 10+.

```bash
pnpm install
pnpm dev
```

Mở URL Vite hiển thị trong terminal. Nhấn **START RACE**, dùng **Arrow Left/Right** hoặc **A/D** để lái và **Space** để kích hoạt nitro.

## Kiểm tra và build

```bash
pnpm check
pnpm build
pnpm preview
```

## Deploy lên GitHub

Có thể đưa toàn bộ nội dung trong gói ZIP lên một repository GitHub mới. Để chạy trên GitHub Pages, cấu hình Pages bằng GitHub Actions hoặc dùng một host tĩnh như Vercel, Netlify hay Cloudflare Pages. Đây là ứng dụng SPA nên host cần fallback mọi route về `index.html`.

Gói GitHub đã bao gồm ảnh art direction cục bộ trong `client/public/neon-apex-reference.png`, vì vậy không phụ thuộc vào Manus Storage.

## Cấu trúc chính

| Đường dẫn | Vai trò |
|---|---|
| `client/src/game/scene.ts` | Scene Babylon.js, đường đua, xe, camera và gameplay loop |
| `client/src/components/GameCanvas.tsx` | Vòng đời canvas Babylon trong React và HUD |
| `client/src/index.css` | Giao diện neon, màn hình mở đầu và responsive HUD |
| `client/src/App.tsx` | Entry component toàn màn hình |
| `PLAN.md`, `STRUCTURE.md`, `ASSETS.md` | Tài liệu thiết kế và asset manifest |

## License

MIT. Các asset được tạo riêng cho dự án này; hãy kiểm tra quyền sử dụng trước khi tái phân phối chúng trong sản phẩm thương mại.

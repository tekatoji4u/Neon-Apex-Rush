# Memory

- Project initialized as WebDev `web-static` at `/home/ubuntu/neon-apex-rush`.
- Babylon.js 9.27.1 installed.
- Generated visual target stored at `/home/ubuntu/webdev-static-assets/neon-apex-reference.png` and uploaded to WebDev storage.
- Keep the game self-contained and avoid backend/server changes.

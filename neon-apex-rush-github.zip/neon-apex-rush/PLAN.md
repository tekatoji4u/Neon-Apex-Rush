# Game Plan: Neon Apex Rush

## Risk Tasks

### 1. Arcade vehicle motion and chase camera
- **Why isolated:** Vehicle physics and third-person camera can feel unstable if acceleration, lane drift, and camera smoothing are mixed.
- **Approach:** Use deterministic arcade steering on a forward-moving track, clamp lateral movement to road bounds, add damped camera follow and a small nitro FOV boost instead of a physics plugin.
- **Verify:** Arrow/A-D steering moves the car responsively, nitro increases speed and camera energy, releasing input settles the car without snapping.

### 2. Procedural 3D road dressing
- **Why isolated:** Repeated road segments, rails, palms, and traffic need stable placement while the player advances.
- **Approach:** Build a compact coastal road from repeated meshes and recycle decorative segments by shifting their Z positions.
- **Verify:** Road remains continuous during a 30-second run; no visible gaps or camera clipping.

## Main Build

- **Assets needed:** Generated 16:9 art-direction reference used as a sky/visual target; procedural low-poly supercars, road, glowing rails, palms, ocean, HUD.
- **Verify:**
  - Movement direction matches keyboard input; nitro responds to Space/Shift.
  - Position, lap, speed, and nitro HUD are readable and do not overlap.
  - Opponent cars and roadside barriers are visible with no missing textures.
  - Game opens full-screen and reacts to the Enter/Play button.
  - No browser console errors and `pnpm check` passes.
  - Palette, camera angle, visual density, and neon coastal racing mood match the reference.
  - Screenshot verification at desktop viewport and deterministic `?demo` mode.

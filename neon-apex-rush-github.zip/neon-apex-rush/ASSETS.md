# Assets

**Art direction:** Premium 3D arcade racing at sunset on a coastal highway. Saturated electric cyan and hot magenta neon rails contrast with amber-orange sky, cobalt vehicles, ocean cliffs, palms, and a clean esports-style HUD.

| Asset | Source | Use |
|---|---|---|
| `neon-apex-reference.png` | Manus built-in image generation | Visual target and optional Babylon background texture |
| Cars, road, rails, palms, ocean | Procedural Babylon meshes | Runtime 3D gameplay assets |

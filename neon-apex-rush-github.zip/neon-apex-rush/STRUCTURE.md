# Structure

- `client/src/components/GameCanvas.tsx`: React lifecycle wrapper for Babylon Engine.
- `client/src/game/scene.ts`: Scene factory, environment, input, render loop, and `GameHandle`.
- `client/src/game/vehicles.ts`: Procedural car mesh factory and vehicle tuning.
- `client/src/App.tsx`: Full-screen shell with DOM HUD and start overlay.
- `client/src/index.css`: Neon racing visual system, HUD panels, responsive controls.

Babylon owns rendering and transforms. The game loop owns arcade movement and camera smoothing. React only renders the canvas/HUD frame and start state.
